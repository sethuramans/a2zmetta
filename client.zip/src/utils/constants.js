export const storage = {
    USER: 'user',
    TOKEN: 'token',
    REWARD_START_TIME: 'rewardTimerStart'
};